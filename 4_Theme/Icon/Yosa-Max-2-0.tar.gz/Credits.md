# Credits #

## Many thanks to the creator/creators of these (listed below) icon themes, in which I used them as the base of this icon theme.
## I re-used some of these icon themes, as well as edited, changed, and modified some of them.

* The creators of La Capitaine icon theme, in which this icon theme is based on.

## Other icon themes that also influence this icon theme :
* The creators of Deepin icon theme.
* The creators of Flattr icon theme.
* The creators of Papirus icon theme.
* The creators of Luv icon theme.
* The creators of Antu icon theme.
* The creators of Emerald icon theme.


